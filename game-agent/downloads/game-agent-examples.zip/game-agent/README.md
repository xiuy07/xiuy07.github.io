# 配套示例怎么使用

先读讲义中的例子并预测输出，再运行单份脚本；参数和关键代码都可以修改。以下命令在项目根目录执行。

| 脚本 | 依赖 | 内容 | 当前状态 |
|---|---|---|---|
| 01_trajectory.py | Python标准库 | 输入验证、成功率、步数和边界 | 已运行 |
| 02_linear_numpy.py | NumPy | 广播、梯度差分、教学回归训练 | 已运行 |
| 03_probability.py | Python标准库 | softmax、采样和Wilson区间 | 已运行 |
| 04_torch_mlp.py | PyTorch CPU | 自动微分、XOR训练、保存加载 | 已运行 |
| 05_decision.py | Python标准库 | 价值迭代、表格Q-learning | 已运行 |
| 06_attention.py | PyTorch CPU | 注意力手算与因果性 | 已运行 |
| 07_tiny_lm.py | PyTorch CPU | 字符级因果小模型教学训练 | 已运行，没有独立测试集 |
| 08_minigrid_random.py | gymnasium、minigrid | DoorKey随机动作与合法观察记录 | 依赖缺失，未实际运行 |
| 09_foundations_lab.py | 按章节使用NumPy，第5课另需PyTorch CPU | 重算11课补充算例，可逐课运行 | 运行结果见验证记录 |

```powershell
python examples/01_trajectory.py
python examples/02_linear_numpy.py
python examples/04_torch_mlp.py --save-dir runs/my-mlp-v1
python examples/run_all.py --output runs/my-check-v2
python examples/09_foundations_lab.py --lesson 03
```

09脚本可按01至11选择一课；不带--lesson则核对全部11课算例。先在纸上算，再运行核对输出；随后改一个输入，重新预测。它检查教学数值与机制，不运行MiniGrid或真实模型API。原run_all.py仍只覆盖01至07，不要把新脚本的核对混入旧批次结果。

04使用新目录保存checkpoint；批量runner也要求新输出目录。单个脚本默认只打印结果，runner保存每份stdout、stderr、命令、耗时、源码哈希与summary.json。使用虚拟环境时将python替换为对应解释器路径。

08在依赖就绪后可单独运行：`python examples/08_minigrid_random.py --output runs/my-doorkey.json`。父目录需已存在，输出文件不能已存在。其成功判断明确限定为DoorKey的终止与正目标奖励约定，不是通用的“奖励大于0等于成功”。它不读取隐藏地图，也不调用LLM。

本次真实运行结果见根目录[验证记录](https://xiuy07.github.io/game-agent/验证记录.html)和runs/lecture-check-v1。不要将自检通过、教学数据效果或程序打印的预期值当作真实智能体研究结果。
