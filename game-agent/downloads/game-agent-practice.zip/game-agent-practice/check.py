"""Run the public practice cases in a child Python process with a time limit."""
import argparse
import copy
import importlib.util
import json
import math
from numbers import Integral, Real
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MARKER = '__PRACTICE_RESULT__'


def decode(value):
    if isinstance(value, list):
        return [decode(v) for v in value]
    if isinstance(value, dict):
        if '$float' in value:
            return float(value['$float'])
        if '$array' in value:
            import numpy as np
            array = np.asarray(decode(value['$array']), dtype=float)
            return array.reshape(value['shape']) if 'shape' in value else array
        return {k: decode(v) for k, v in value.items()}
    return value


def same(actual, expected):
    if expected is None:
        return actual is None
    if isinstance(expected, dict):
        return isinstance(actual, dict) and set(actual) == set(expected) and all(same(actual[k], v) for k, v in expected.items())
    if isinstance(expected, list):
        return isinstance(actual, (list, tuple)) and len(actual) == len(expected) and all(same(a, b) for a, b in zip(actual, expected))
    if isinstance(expected, int):
        return isinstance(actual, Integral) and not isinstance(actual, bool) and actual == expected
    if isinstance(expected, float):
        return isinstance(actual, Real) and not isinstance(actual, bool) and math.isclose(float(actual), expected, rel_tol=1e-7, abs_tol=1e-8)
    return actual == expected


def unchanged(actual, before):
    if type(actual) is not type(before):
        return False
    if hasattr(actual, 'shape'):
        import numpy as np
        return isinstance(actual, np.ndarray) and np.array_equal(actual, before, equal_nan=True)
    if isinstance(actual, list):
        return isinstance(before, list) and len(actual) == len(before) and all(unchanged(a, b) for a, b in zip(actual, before))
    if isinstance(actual, dict):
        return isinstance(before, dict) and actual.keys() == before.keys() and all(unchanged(actual[k], before[k]) for k in actual)
    if isinstance(actual, float) and isinstance(before, float) and math.isnan(actual) and math.isnan(before):
        return True
    return actual == before


def loss_function(name):
    if name == 'quadratic':
        return lambda t: .5*sum(v*v for v in t)
    if name == 'mixed':
        return lambda t: t[0]**2+3*t[0]*t[1]+2*t[1]**2
    if name == 'constant':
        return lambda t: 3.
    raise ValueError('Unknown public loss function')


def worker(task, path):
    bank = json.loads((ROOT/'cases'/f'{task}.json').read_text(encoding='utf-8'))
    spec = importlib.util.spec_from_file_location('student_solution', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    fn = getattr(module, bank['function'])
    checks = []
    for case in bank['cases']:
        try:
            args = decode(case['args'])
            before = copy.deepcopy(args)
            if task == '03':
                args.insert(0, loss_function(case.get('fn', 'quadratic')))
                before.insert(0, args[0])
            if case.get('raises'):
                try:
                    fn(*args)
                except ValueError:
                    pass
                else:
                    raise AssertionError('应抛出ValueError，实际未抛出')
            else:
                result = fn(*args)
                if 'shape' in case:
                    import numpy as np
                    if not isinstance(result, np.ndarray) or list(result.shape) != case['shape']:
                        raise AssertionError(f'应返回ndarray，形状{case["shape"]}；实际类型{type(result).__name__}')
                    if result.dtype.kind != 'f':
                        raise AssertionError('应返回浮点数组')
                    if not np.allclose(result, case['expected'], rtol=1e-7, atol=1e-8):
                        raise AssertionError(f'数值不符；实际{result.tolist()}，期望{case["expected"]}')
                elif not same(result, case['expected']):
                    raise AssertionError(f'结果不符；实际{result!r}，期望{case["expected"]!r}')
            if not all(unchanged(a, b) for a, b in zip(args, before)):
                raise AssertionError('函数修改了传入的输入')
            checks.append(dict(name=case['name'], passed=True))
        except Exception as exc:
            checks.append(dict(name=case['name'], passed=False, detail=f'{type(exc).__name__}: {exc}'[:400]))
    report = dict(task=task, function=bank['function'], cases=checks,
                  passed=sum(c['passed'] for c in checks), total=len(checks))
    print(MARKER+json.dumps(report, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=('01', '02', '03', '04'))
    parser.add_argument('--file', type=Path)
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    path = (args.file or ROOT/'work'/f'task_{args.task}.py').resolve()
    if not path.is_file():
        parser.error(f'尚未建立作业；先运行 python start.py {args.task}')
    if args.worker:
        worker(args.task, path)
        return
    command = [sys.executable, str(Path(__file__).resolve()), args.task, '--file', str(path), '--worker']
    try:
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                                encoding='utf-8', errors='replace', timeout=15)
    except subprocess.TimeoutExpired:
        print('检查超过15秒。先查死循环；本题不需要训练模型或大量计算。')
        raise SystemExit(2)
    payloads = [line[len(MARKER):] for line in result.stdout.splitlines() if line.startswith(MARKER)]
    if result.returncode or not payloads:
        print('未能载入作业或依赖，请检查函数名、语法，以及是否误在模块顶层调用input。')
        print(result.stderr[-1600:])
        raise SystemExit(2)
    report = json.loads(payloads[-1])
    if args.json:
        print(json.dumps(report, ensure_ascii=False))
    else:
        print(f'第{report["task"]}课：{report["passed"]}/{report["total"]}个公开检查通过')
        for case in report['cases']:
            print(('通过' if case['passed'] else '待修正')+' '+case['name'])
            if not case['passed']:
                print('  '+case['detail'])
        print('这些是公开功能检查；还要能解释分母、边界和实现过程。')
    raise SystemExit(0 if report['passed'] == report['total'] else 1)


if __name__ == '__main__':
    main()
