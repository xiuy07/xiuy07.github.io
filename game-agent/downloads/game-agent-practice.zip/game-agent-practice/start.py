"""Create one working copy without overwriting an existing student solution."""
import argparse
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=('01', '02', '03', '04'))
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    target = root/'work'/f'task_{args.task}.py'
    target.parent.mkdir(exist_ok=True)
    try:
        with target.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write((root/'templates'/target.name).read_text(encoding='utf-8'))
    except FileExistsError:
        print(f'已保留已有作业：{target}')
        print('直接继续编辑；初始化不会覆盖你的代码。')
        return
    print(f'已建立空白作业：{target}')
    print(f'编辑后检查："{sys.executable}" "{root / "check.py"}" {args.task}')


if __name__ == '__main__':
    main()
