"""第1课B2：只完成函数，不在导入时读取文件或input。"""


def summarize_basic(rows):
    """返回n、success_rate、mean_all、mean_success；非法记录抛ValueError。

    rows必须是list；success必须是bool；steps必须为非负int且排除bool。
    空输入或没有成功局时，无定义的比率/均值用None。不修改输入。
    """
    raise NotImplementedError("请独立实现统计函数")
