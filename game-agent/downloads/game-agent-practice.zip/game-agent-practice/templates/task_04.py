"""第4课B2：本题只需要Python标准库。"""


def binary_metrics(truth, pred):
    """两个等长0/1整数列表，返回tp/fp/fn/tn及accuracy/precision/recall。

    空输入允许；无定义的比率为None。非法值、bool或长度不等抛ValueError。
    不修改输入，不把没有正类预测的precision写成0。
    """
    raise NotImplementedError("请独立实现二分类指标")
