"""第2课B2。需要NumPy；不安装其他机器学习框架。"""


def predict_strict(X, w, b):
    """二维X、一维w、有限标量b，返回浮点ndarray，形状(N,)。

    拒绝秩不符、维度不匹配、NaN和无穷；空批次允许。不修改输入。
    """
    raise NotImplementedError("请独立实现严格批量预测")
