"""第3课B2。需要NumPy。"""


def numerical_grad(fn, theta, h=1e-6):
    """用逐坐标中心差分返回与一维theta同形的浮点ndarray。

    theta须有限；h须有限且大于0。fn接收一维向量并返回标量。
    不改动原theta；不调用自动微分。
    """
    raise NotImplementedError("请独立实现中心差分")
