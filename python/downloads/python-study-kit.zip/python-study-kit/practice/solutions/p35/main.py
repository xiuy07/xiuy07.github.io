"""p35 在 solve(data) 中完成题目，题面见 practice/statements。"""

def solve(data):
    # TODO：实现后运行 python practice/judge.py p35
    raise NotImplementedError("请完成本题")
